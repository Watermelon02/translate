package com.experiment.lib_react.observer;

public interface OnNextAction<T> {
    void run(T t);
}
