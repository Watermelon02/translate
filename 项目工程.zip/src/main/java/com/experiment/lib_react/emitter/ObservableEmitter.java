package com.experiment.lib_react.emitter;

public interface ObservableEmitter<T> extends Emitter<T> {
}
