package com.experiment.translate.viewmodel;

public interface ViewModel {
    public void init();
}
