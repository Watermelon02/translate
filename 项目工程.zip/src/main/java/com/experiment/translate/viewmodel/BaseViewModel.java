package com.experiment.translate.viewmodel;

public class BaseViewModel implements ViewModel {
    @Override
    public void init() {

    }

}
