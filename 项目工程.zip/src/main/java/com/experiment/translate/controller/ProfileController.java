package com.experiment.translate.controller;

import com.experiment.translate.ControlledStage;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import org.w3c.dom.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class ProfileController extends ControlledStage implements Initializable {

@FXML
    Text text_name;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        int a = 1;
    }
}