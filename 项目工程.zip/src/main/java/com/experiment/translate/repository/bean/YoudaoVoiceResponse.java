package com.experiment.translate.repository.bean;

public class YoudaoVoiceResponse {
    
}
